package ut.com.example.plugins.tutorial.jira.jira.customfields;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.example.plugins.tutorial.jira.jira.customfields.BalancedParentheses;
import static org.junit.Assert.assertEquals;

import java.util.Random;

import static org.mockito.Mockito.*;

/**
 * @since 3.5
 */
public class BalancedParenthesesTest {

    @Before
    public void setup() {

    }

    @After
    public void tearDown() {

    }

    String randomString( int len ) {
        final String s = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJLMNOPQRSTUVWXYZ1234567890@#$%&*,:.;/!'\"\\[{}<>]";
        Random rnd = new Random();
        StringBuilder sb = new StringBuilder( len );
        for( int i = 0; i < len; i++ )
            sb.append( s.charAt( rnd.nextInt(s.length()) ) );
        return sb.toString();
    }

    @Test
    public void testSomething() {

        //BalancedParentheses testClass = new BalancedParentheses();

        String balancedInput = "()" +  randomString(10 + (int)(Math.random() * (30 - 5))) + "(()())()";
        String unbalancedString = "())))" +  randomString(10 + (int)(Math.random() * (30 - 5))) + "(((";

        assertEquals(BalancedParentheses.isBalanced(balancedInput), true);
        assertEquals(BalancedParentheses.isBalanced(unbalancedString), false);


       // throw new Exception("BalancedParentheses has no tests!");

    }

}
