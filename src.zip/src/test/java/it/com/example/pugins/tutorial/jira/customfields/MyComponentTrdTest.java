package it.com.example.pugins.tutorial.jira.customfields;

import org.junit.Test;
import static junit.framework.Assert.assertEquals;

public class MyComponentTrdTest extends FuncTestCase{


    @Test
    public void testSomeFailure()
    {
        navigation.login("admin", "admin");
        final String issueKey = navigation.issue().createIssue("Homosapien", "Bug", "This is a first bug");
        assertEquals(true,true);
    }

}
