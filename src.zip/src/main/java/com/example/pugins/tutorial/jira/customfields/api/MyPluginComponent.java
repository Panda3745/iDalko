package com.example.pugins.tutorial.jira.customfields.api;

public interface MyPluginComponent
{
    String getName();
}