package com.example.plugins.tutorial.jira.jira.customfields;

import com.atlassian.jira.issue.customfields.impl.AbstractSingleFieldType;
import com.atlassian.jira.issue.customfields.persistence.PersistenceFieldType;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.JiraImport;
import com.atlassian.jira.issue.customfields.manager.GenericConfigManager;
import com.atlassian.jira.issue.customfields.persistence.CustomFieldValuePersister;
import com.atlassian.jira.issue.customfields.impl.FieldValidationException;

import java.util.List;
import java.util.Map;
import java.util.Stack;

@Scanned
public class BalancedParentheses extends AbstractSingleFieldType<String> {

    public BalancedParentheses(@JiraImport CustomFieldValuePersister customFieldValuePersister,@JiraImport GenericConfigManager genericConfigManager) {
        super(customFieldValuePersister, genericConfigManager);
    }

    @Override
    public String getStringFromSingularObject(final String singularObject) {
        if (singularObject == null)
            return null;
        else
            return singularObject;
    }

    @Override
    public String getSingularObjectFromString(final String string) throws FieldValidationException {
        if (string == null)
            return null;
        if(isBalanced(string)) {
            return string;
        } else {
            throw new FieldValidationException("Un-Balanced parentheses");
        }
    }

    @Override
    protected PersistenceFieldType getDatabaseType() {
        return PersistenceFieldType.TYPE_LIMITED_TEXT;
    }

    @Override
    protected String getObjectFromDbValue(final Object databaseValue) throws FieldValidationException {
        return getSingularObjectFromString((String) databaseValue);
    }

    @Override
    protected Object getDbValueFromObject(final String customFieldObject) {
        return getStringFromSingularObject(customFieldObject);
    }

    public static Boolean isBalanced (String input) {
        input = input.replaceAll("([^(|)])", "");

        Stack<Character> stack = new Stack<>();
        char headEl = 0;
        for (char c : input.toCharArray()) {
            if(!stack.isEmpty())
                headEl = stack.peek();

            stack.push(c);
            if (stack.size() > 1) {
                if(headEl == '(' && stack.peek() == ')') {
                    stack.pop();
                    stack.pop();
                }
            }
        }

        return stack.isEmpty();
    }


}